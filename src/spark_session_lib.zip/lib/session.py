from typing import Dict
from pyspark.sql import SparkSession


class Session:
    def __init__(self, application_name: str, configurations: dict = {}) ->  None:
        self._spark = SparkSession.builder.appName(application_name).getOrCreate()
        if not len(configurations):
            self._spark.sparkContext._conf.setAll(configurations)
    
    def set_config(self, configurations: dict = {} ) -> None:
            self._spark.sparkContext._conf.setAll(configurations)

    def get(self):
        return self._spark
    
    def get_configurations(self) -> dict:
        return self._spark.sparkContext._conf.getAll()

    def close(self) -> None:
        self._spark.stop()

